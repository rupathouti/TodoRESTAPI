﻿namespace DirectoryManagementApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbSysDriveDetails = new System.Windows.Forms.ComboBox();
            this.txtSysDriveDetails = new System.Windows.Forms.TextBox();
            this.btnSysDriveDetails = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFileNamePath = new System.Windows.Forms.TextBox();
            this.txtSubDirectoryName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbShowDirectoryDetails = new System.Windows.Forms.ComboBox();
            this.btnCreateNewDirectory = new System.Windows.Forms.Button();
            this.btnCreateSubDirectory = new System.Windows.Forms.Button();
            this.btnShowSubDirectoryFiles = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSourceDirectoryPathAndName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDestinationDirectoryPathAndName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnCopyDirectory = new System.Windows.Forms.Button();
            this.txtEnterDrivePathAndFileName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtFileContent = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtReadContent = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtFindWords = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtAppendContent = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtEnterPathAndRenameFileName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtEnterOldValue = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtEnterNewValue = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnFind = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnAppend = new System.Windows.Forms.Button();
            this.btnRename = new System.Windows.Forms.Button();
            this.btnReplace = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(530, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Directory Management App";
            // 
            // cbSysDriveDetails
            // 
            this.cbSysDriveDetails.FormattingEnabled = true;
            this.cbSysDriveDetails.Location = new System.Drawing.Point(30, 61);
            this.cbSysDriveDetails.Name = "cbSysDriveDetails";
            this.cbSysDriveDetails.Size = new System.Drawing.Size(249, 21);
            this.cbSysDriveDetails.TabIndex = 1;
            this.cbSysDriveDetails.SelectedIndexChanged += new System.EventHandler(this.CbSysDriveDetails_SelectedIndexChanged);
            // 
            // txtSysDriveDetails
            // 
            this.txtSysDriveDetails.Location = new System.Drawing.Point(30, 88);
            this.txtSysDriveDetails.Multiline = true;
            this.txtSysDriveDetails.Name = "txtSysDriveDetails";
            this.txtSysDriveDetails.Size = new System.Drawing.Size(249, 80);
            this.txtSysDriveDetails.TabIndex = 2;
            // 
            // btnSysDriveDetails
            // 
            this.btnSysDriveDetails.Location = new System.Drawing.Point(30, 175);
            this.btnSysDriveDetails.Name = "btnSysDriveDetails";
            this.btnSysDriveDetails.Size = new System.Drawing.Size(249, 23);
            this.btnSysDriveDetails.TabIndex = 3;
            this.btnSysDriveDetails.Text = "Show Your System Drive Details";
            this.btnSysDriveDetails.UseVisualStyleBackColor = true;
            this.btnSysDriveDetails.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(306, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter Directory Path And Name";
            // 
            // txtFileNamePath
            // 
            this.txtFileNamePath.Location = new System.Drawing.Point(467, 69);
            this.txtFileNamePath.Name = "txtFileNamePath";
            this.txtFileNamePath.Size = new System.Drawing.Size(249, 20);
            this.txtFileNamePath.TabIndex = 5;
            // 
            // txtSubDirectoryName
            // 
            this.txtSubDirectoryName.Location = new System.Drawing.Point(467, 105);
            this.txtSubDirectoryName.Name = "txtSubDirectoryName";
            this.txtSubDirectoryName.Size = new System.Drawing.Size(249, 20);
            this.txtSubDirectoryName.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(306, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Enter Sub Directory Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(308, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Show Directory Details";
            // 
            // cbShowDirectoryDetails
            // 
            this.cbShowDirectoryDetails.FormattingEnabled = true;
            this.cbShowDirectoryDetails.Location = new System.Drawing.Point(467, 155);
            this.cbShowDirectoryDetails.Name = "cbShowDirectoryDetails";
            this.cbShowDirectoryDetails.Size = new System.Drawing.Size(249, 21);
            this.cbShowDirectoryDetails.TabIndex = 9;
            // 
            // btnCreateNewDirectory
            // 
            this.btnCreateNewDirectory.Location = new System.Drawing.Point(722, 67);
            this.btnCreateNewDirectory.Name = "btnCreateNewDirectory";
            this.btnCreateNewDirectory.Size = new System.Drawing.Size(151, 23);
            this.btnCreateNewDirectory.TabIndex = 11;
            this.btnCreateNewDirectory.Text = "Create New Directory";
            this.btnCreateNewDirectory.UseVisualStyleBackColor = true;
            this.btnCreateNewDirectory.Click += new System.EventHandler(this.BtnCreateNewDirectory_Click);
            // 
            // btnCreateSubDirectory
            // 
            this.btnCreateSubDirectory.Location = new System.Drawing.Point(722, 105);
            this.btnCreateSubDirectory.Name = "btnCreateSubDirectory";
            this.btnCreateSubDirectory.Size = new System.Drawing.Size(151, 23);
            this.btnCreateSubDirectory.TabIndex = 12;
            this.btnCreateSubDirectory.Text = "Create Sub Directory";
            this.btnCreateSubDirectory.UseVisualStyleBackColor = true;
            this.btnCreateSubDirectory.Click += new System.EventHandler(this.BtnCreateSubDirectory_Click);
            // 
            // btnShowSubDirectoryFiles
            // 
            this.btnShowSubDirectoryFiles.Location = new System.Drawing.Point(722, 153);
            this.btnShowSubDirectoryFiles.Name = "btnShowSubDirectoryFiles";
            this.btnShowSubDirectoryFiles.Size = new System.Drawing.Size(170, 23);
            this.btnShowSubDirectoryFiles.TabIndex = 13;
            this.btnShowSubDirectoryFiles.Text = "Show Sub-Directory and Files";
            this.btnShowSubDirectoryFiles.UseVisualStyleBackColor = true;
            this.btnShowSubDirectoryFiles.Click += new System.EventHandler(this.BtnShowSubDirectoryFiles_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(922, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(248, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Copy Directory One Drive to Another Drive";
            // 
            // txtSourceDirectoryPathAndName
            // 
            this.txtSourceDirectoryPathAndName.Location = new System.Drawing.Point(981, 69);
            this.txtSourceDirectoryPathAndName.Name = "txtSourceDirectoryPathAndName";
            this.txtSourceDirectoryPathAndName.Size = new System.Drawing.Size(189, 20);
            this.txtSourceDirectoryPathAndName.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(975, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Enter Source Directory Path And Name";
            // 
            // txtDestinationDirectoryPathAndName
            // 
            this.txtDestinationDirectoryPathAndName.Location = new System.Drawing.Point(981, 117);
            this.txtDestinationDirectoryPathAndName.Name = "txtDestinationDirectoryPathAndName";
            this.txtDestinationDirectoryPathAndName.Size = new System.Drawing.Size(189, 20);
            this.txtDestinationDirectoryPathAndName.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(959, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(211, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Enter Destination Directory Path And Name";
            // 
            // btnCopyDirectory
            // 
            this.btnCopyDirectory.Location = new System.Drawing.Point(978, 153);
            this.btnCopyDirectory.Name = "btnCopyDirectory";
            this.btnCopyDirectory.Size = new System.Drawing.Size(192, 23);
            this.btnCopyDirectory.TabIndex = 19;
            this.btnCopyDirectory.Text = "Copy Directory";
            this.btnCopyDirectory.UseVisualStyleBackColor = true;
            this.btnCopyDirectory.Click += new System.EventHandler(this.BtnCopyDirectory_Click);
            // 
            // txtEnterDrivePathAndFileName
            // 
            this.txtEnterDrivePathAndFileName.Location = new System.Drawing.Point(862, 247);
            this.txtEnterDrivePathAndFileName.Name = "txtEnterDrivePathAndFileName";
            this.txtEnterDrivePathAndFileName.Size = new System.Drawing.Size(308, 20);
            this.txtEnterDrivePathAndFileName.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(894, 231);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(211, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Enter Your Drive Path And Filename";
            // 
            // txtFileContent
            // 
            this.txtFileContent.Location = new System.Drawing.Point(27, 309);
            this.txtFileContent.Multiline = true;
            this.txtFileContent.Name = "txtFileContent";
            this.txtFileContent.Size = new System.Drawing.Size(183, 93);
            this.txtFileContent.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label9.Location = new System.Drawing.Point(54, 293);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Enter Your File Content";
            // 
            // txtReadContent
            // 
            this.txtReadContent.Location = new System.Drawing.Point(233, 309);
            this.txtReadContent.Multiline = true;
            this.txtReadContent.Name = "txtReadContent";
            this.txtReadContent.Size = new System.Drawing.Size(183, 93);
            this.txtReadContent.TabIndex = 26;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label10.Location = new System.Drawing.Point(260, 293);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Read The Existing File Content";
            // 
            // txtFindWords
            // 
            this.txtFindWords.Location = new System.Drawing.Point(437, 309);
            this.txtFindWords.Multiline = true;
            this.txtFindWords.Name = "txtFindWords";
            this.txtFindWords.Size = new System.Drawing.Size(183, 93);
            this.txtFindWords.TabIndex = 28;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label11.Location = new System.Drawing.Point(464, 293);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Find The Words in the File";
            // 
            // txtAppendContent
            // 
            this.txtAppendContent.Location = new System.Drawing.Point(641, 309);
            this.txtAppendContent.Multiline = true;
            this.txtAppendContent.Name = "txtAppendContent";
            this.txtAppendContent.Size = new System.Drawing.Size(195, 93);
            this.txtAppendContent.TabIndex = 30;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label12.Location = new System.Drawing.Point(643, 293);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(181, 13);
            this.label12.TabIndex = 29;
            this.label12.Text = "Append The Contents to Existing File";
            // 
            // txtEnterPathAndRenameFileName
            // 
            this.txtEnterPathAndRenameFileName.Location = new System.Drawing.Point(862, 309);
            this.txtEnterPathAndRenameFileName.Name = "txtEnterPathAndRenameFileName";
            this.txtEnterPathAndRenameFileName.Size = new System.Drawing.Size(308, 20);
            this.txtEnterPathAndRenameFileName.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(859, 293);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(189, 13);
            this.label13.TabIndex = 31;
            this.label13.Text = "Enter Path and Rename the File Name\r\n";
            // 
            // txtEnterOldValue
            // 
            this.txtEnterOldValue.Location = new System.Drawing.Point(862, 405);
            this.txtEnterOldValue.Multiline = true;
            this.txtEnterOldValue.Name = "txtEnterOldValue";
            this.txtEnterOldValue.Size = new System.Drawing.Size(113, 42);
            this.txtEnterOldValue.TabIndex = 34;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(859, 389);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 13);
            this.label14.TabIndex = 33;
            this.label14.Text = "Enter Old Value";
            // 
            // txtEnterNewValue
            // 
            this.txtEnterNewValue.Location = new System.Drawing.Point(1001, 405);
            this.txtEnterNewValue.Multiline = true;
            this.txtEnterNewValue.Name = "txtEnterNewValue";
            this.txtEnterNewValue.Size = new System.Drawing.Size(110, 42);
            this.txtEnterNewValue.TabIndex = 36;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(998, 389);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 13);
            this.label15.TabIndex = 35;
            this.label15.Text = "Enter New Value";
            // 
            // btnFind
            // 
            this.btnFind.Location = new System.Drawing.Point(467, 417);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(107, 23);
            this.btnFind.TabIndex = 37;
            this.btnFind.Text = "Find";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.BtnFind_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(263, 417);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(107, 23);
            this.btnRead.TabIndex = 38;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.BtnRead_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(57, 417);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(107, 23);
            this.btnWrite.TabIndex = 39;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.BtnWrite_Click);
            // 
            // btnAppend
            // 
            this.btnAppend.Location = new System.Drawing.Point(671, 417);
            this.btnAppend.Name = "btnAppend";
            this.btnAppend.Size = new System.Drawing.Size(107, 23);
            this.btnAppend.TabIndex = 40;
            this.btnAppend.Text = "Append";
            this.btnAppend.UseVisualStyleBackColor = true;
            this.btnAppend.Click += new System.EventHandler(this.BtnAppend_Click);
            // 
            // btnRename
            // 
            this.btnRename.Location = new System.Drawing.Point(925, 335);
            this.btnRename.Name = "btnRename";
            this.btnRename.Size = new System.Drawing.Size(107, 23);
            this.btnRename.TabIndex = 41;
            this.btnRename.Text = "Rename";
            this.btnRename.UseVisualStyleBackColor = true;
            this.btnRename.Click += new System.EventHandler(this.BtnRename_Click);
            // 
            // btnReplace
            // 
            this.btnReplace.Location = new System.Drawing.Point(925, 453);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(107, 23);
            this.btnReplace.TabIndex = 42;
            this.btnReplace.Text = "Replace";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.BtnReplace_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 201);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(1192, 16);
            this.label16.TabIndex = 43;
            this.label16.Text = "=================================================================================" +
    "===================================================================";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 502);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.btnReplace);
            this.Controls.Add(this.btnRename);
            this.Controls.Add(this.btnAppend);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.txtEnterNewValue);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtEnterOldValue);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtEnterPathAndRenameFileName);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtAppendContent);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtFindWords);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtReadContent);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtFileContent);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtEnterDrivePathAndFileName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnCopyDirectory);
            this.Controls.Add(this.txtDestinationDirectoryPathAndName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtSourceDirectoryPathAndName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnShowSubDirectoryFiles);
            this.Controls.Add(this.btnCreateSubDirectory);
            this.Controls.Add(this.btnCreateNewDirectory);
            this.Controls.Add(this.cbShowDirectoryDetails);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSubDirectoryName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFileNamePath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSysDriveDetails);
            this.Controls.Add(this.txtSysDriveDetails);
            this.Controls.Add(this.cbSysDriveDetails);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Directory Management App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbSysDriveDetails;
        private System.Windows.Forms.TextBox txtSysDriveDetails;
        private System.Windows.Forms.Button btnSysDriveDetails;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFileNamePath;
        private System.Windows.Forms.TextBox txtSubDirectoryName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbShowDirectoryDetails;
        private System.Windows.Forms.Button btnCreateNewDirectory;
        private System.Windows.Forms.Button btnCreateSubDirectory;
        private System.Windows.Forms.Button btnShowSubDirectoryFiles;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSourceDirectoryPathAndName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDestinationDirectoryPathAndName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnCopyDirectory;
        private System.Windows.Forms.TextBox txtEnterDrivePathAndFileName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtFileContent;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtReadContent;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtFindWords;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtAppendContent;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtEnterPathAndRenameFileName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtEnterOldValue;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtEnterNewValue;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Button btnAppend;
        private System.Windows.Forms.Button btnRename;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.Label label16;
    }
}

