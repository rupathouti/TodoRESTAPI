﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DirectoryManagementApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                cbSysDriveDetails.Items.Clear();
                String[] drives = Directory.GetLogicalDrives();
                for (int i = 0; i < drives.Length; i++)
                {
                    cbSysDriveDetails.Items.Add(drives[i]);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CbSysDriveDetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string driveName = cbSysDriveDetails.SelectedItem.ToString();
                DriveInfo driveInfo = new DriveInfo(driveName);
                txtSysDriveDetails.Text = "Your selected Drive is : " + driveName + " \n Total Size of the Drive is: " + driveInfo.TotalSize + "\n Available Free Space in Drive is " + driveInfo.AvailableFreeSpace;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnCreateNewDirectory_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(txtFileNamePath.Text))
                {
                    Directory.CreateDirectory(txtFileNamePath.Text);
                    MessageBox.Show("Directory Created");
                }
                else
                {
                    MessageBox.Show("Please enter correct directory path and file name");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnCreateSubDirectory_Click(object sender, EventArgs e)
        {
            try
            {
                string path = txtFileNamePath.Text;
                DirectoryInfo dirInfo = new DirectoryInfo(path);
                string subName = txtSubDirectoryName.Text;
                dirInfo.CreateSubdirectory(subName);
                MessageBox.Show("Subdirectory has successfully created");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnShowSubDirectoryFiles_Click(object sender, EventArgs e)
        {
            try
            {
                cbShowDirectoryDetails.Items.Clear();
                string path = txtFileNamePath.Text;
                DirectoryInfo dirInfo = new DirectoryInfo(path);
                if (dirInfo.Exists)
                {
                    DirectoryInfo[] subDirs = dirInfo.GetDirectories();

                    foreach (var dir in subDirs)
                    {
                        cbShowDirectoryDetails.Items.Add(dir);
                    }
                    FileInfo[] fInfos = dirInfo.GetFiles();
                    foreach (var fileInfo in fInfos)
                    {
                        cbShowDirectoryDetails.Items.Add(fileInfo);
                    }
                }
                else
                {
                    MessageBox.Show("Directory does not exist, please enter valid directory path and name");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnCopyDirectory_Click(object sender, EventArgs e)
        {
            try
            {
                DirectoryInfo dSourceInfo = new DirectoryInfo(txtSourceDirectoryPathAndName.Text);
                DirectoryInfo dDestinationInfo = new DirectoryInfo(txtDestinationDirectoryPathAndName.Text);
                CopyDirectory(dSourceInfo, dDestinationInfo);
                MessageBox.Show("Directory has copied successfully to another drive");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void CopyDirectory(DirectoryInfo dSource, DirectoryInfo dTarget)
        {
            try
            {
                if (!dTarget.Exists)
                {
                    dTarget.Create();
                    FileInfo[] filesInfo = dSource.GetFiles();
                    foreach (var fileInfo in filesInfo)
                    {
                        fileInfo.CopyTo(Path.Combine(dTarget.FullName, fileInfo.Name));
                    }
                    DirectoryInfo[] dInfos = dSource.GetDirectories();
                    foreach (var dInfo in dInfos)
                    {
                        string target = Path.Combine(dTarget.FullName, dInfo.Name);
                        CopyDirectory(dInfo, new DirectoryInfo(target));
                    }
                }
                else
                {
                    MessageBox.Show("Please enter valid path in source and destination directory");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnWrite_Click(object sender, EventArgs e)
        {
            try
            {
                FileStream fs = new FileStream(txtEnterDrivePathAndFileName.Text, FileMode.Create, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine(txtFileContent.Text);
                sw.Flush();
                fs.Close();
                MessageBox.Show("Content written in File Successfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnRead_Click(object sender, EventArgs e)
        {
            try
            {
                FileStream fs = new FileStream(txtEnterDrivePathAndFileName.Text, FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                txtReadContent.Text = sr.ReadToEnd();
                sr.Close();
                fs.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnFind_Click(object sender, EventArgs e)
        {
            try
            {
                FileStream fs = new FileStream(txtEnterDrivePathAndFileName.Text, FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                string fileContent = sr.ReadToEnd();
                int i = (fileContent.IndexOf(txtFindWords.Text, 0));
                if (i > -1)
                {
                    MessageBox.Show("The word " + txtFindWords.Text + " exist in file");
                }
                else
                {
                    MessageBox.Show("The word " + txtFindWords.Text + " does not exist in file, try anotother word");
                }

                sr.Close();
                fs.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnAppend_Click(object sender, EventArgs e)
        {
            try
            {
                string str = txtEnterDrivePathAndFileName.Text;
                StreamWriter sw = File.AppendText(str);
                sw.WriteLine(txtAppendContent.Text);
                sw.Close();
                MessageBox.Show("File Contents appended successfully");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnRename_Click(object sender, EventArgs e)
        {
            try
            {
                string strSrc = txtEnterDrivePathAndFileName.Text;
                string strRename = txtEnterPathAndRenameFileName.Text;

                FileInfo srcFileInfo = new FileInfo(strSrc);
                if (srcFileInfo.Exists)
                {
                    srcFileInfo.MoveTo(strRename);
                    MessageBox.Show("File renamed successfully");
                }
                else
                {
                    MessageBox.Show("Enter Correct path details for rename");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnReplace_Click(object sender, EventArgs e)
        {
            try
            {
                string text = File.ReadAllText(txtEnterDrivePathAndFileName.Text);
                string value = text.Replace(txtEnterOldValue.Text, txtEnterNewValue.Text);
                File.WriteAllText(txtEnterDrivePathAndFileName.Text, value);
                MessageBox.Show("Successfully replaced");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
