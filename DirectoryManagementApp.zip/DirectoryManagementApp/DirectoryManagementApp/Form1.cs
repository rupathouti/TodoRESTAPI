﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DirectoryManagementApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                comboBox1.Items.Clear();
                String[] drives = Directory.GetLogicalDrives();
                for (int i = 0; i < drives.Length; i++)
                {
                    comboBox1.Items.Add(drives[i]);
                }

            }
            catch (Exception ex)
            {

            }
        }
    }
}
